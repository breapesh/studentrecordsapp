
Imports System
Imports System.IO

Module Program

    ' Location where student records will be stored
    Private ReadOnly filePath As String =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                      "Students.txt")

    Sub Main()

        Dim choice As String

        Do
            Console.Clear()

            Console.WriteLine("========================================")
            Console.WriteLine("     STUDENT RECORDS MANAGEMENT SYSTEM")
            Console.WriteLine("========================================")
            Console.WriteLine("1. Enter Student Record")
            Console.WriteLine("2. Display Student Records")
            Console.WriteLine("3. Exit")
            Console.WriteLine("========================================")
            Console.Write("Choose an option: ")

            choice = Console.ReadLine()

            Select Case choice

                Case "1"
                    EnterStudentRecord()

                Case "2"
                    DisplayStudentRecords()

                Case "3"
                    Console.WriteLine("Thank you for using the system!")

                Case Else
                    Console.WriteLine("Invalid choice. Please try again.")

            End Select

            If choice <> "3" Then
                Console.WriteLine()
                Console.WriteLine("Press any key to continue...")
                Console.ReadKey()
            End If

        Loop While choice <> "3"

    End Sub

    ' Function to enter and save student details
    Sub EnterStudentRecord()

        Console.Clear()
        Console.WriteLine("ENTER STUDENT DETAILS")
        Console.WriteLine("=====================")

        Console.Write("Registration Number: ")
        Dim regNo As String = Console.ReadLine()

        If String.IsNullOrWhiteSpace(regNo) Then
            Console.WriteLine("Registration number cannot be empty.")
            Return
        End If

        Console.Write("Student Name: ")
        Dim studentName As String = Console.ReadLine()

        If String.IsNullOrWhiteSpace(studentName) Then
            Console.WriteLine("Student name cannot be empty.")
            Return
        End If

        Console.Write("Student Marks (0-100): ")
        Dim marks As Integer

        If Not Integer.TryParse(Console.ReadLine(), marks) OrElse
            marks < 0 OrElse marks > 100 Then

            Console.WriteLine("Please enter valid marks between 0 and 100.")
            Return

        End If

        Try

            Dim record As String =
                regNo.Trim() & "|" & studentName.Trim() & "|" & marks.ToString()

            ' AppendAllText adds new records without deleting old records
            File.AppendAllText(filePath, record & Environment.NewLine)

            Console.WriteLine()
            Console.WriteLine("Student record saved successfully!")
            Console.WriteLine("File location: " & filePath)

        Catch ex As IOException

            Console.WriteLine("File error: " & ex.Message)

        Catch ex As UnauthorizedAccessException

            Console.WriteLine("Permission error: " & ex.Message)

        Catch ex As Exception

            Console.WriteLine("An unexpected error occurred: " & ex.Message)

        End Try

    End Sub

    ' Function to display previously saved student records
    Sub DisplayStudentRecords()

        Console.Clear()
        Console.WriteLine("SAVED STUDENT RECORDS")
        Console.WriteLine("=====================")

        Try

            If Not File.Exists(filePath) Then

                Console.WriteLine("No student records found.")
                Console.WriteLine("The records file does not exist yet.")
                Return

            End If

            Dim records() As String = File.ReadAllLines(filePath)

            If records.Length = 0 Then

                Console.WriteLine("The student records file is empty.")
                Return

            End If

            Console.WriteLine()
            Console.WriteLine("REG NO. | STUDENT NAME | MARKS")
            Console.WriteLine("----------------------------------------")

            For Each record As String In records

                Dim details() As String = record.Split("|"c)

                If details.Length = 3 Then

                    Console.WriteLine(
                        details(0) & " | " &
                        details(1) & " | " &
                        details(2))

                End If

            Next

            Console.WriteLine("----------------------------------------")
            Console.WriteLine("Total records: " & records.Length)

        Catch ex As IOException

            Console.WriteLine("File error: " & ex.Message)

        Catch ex As UnauthorizedAccessException

            Console.WriteLine("Permission error: " & ex.Message)

        Catch ex As Exception

            Console.WriteLine("An unexpected error occurred: " & ex.Message)

        End Try

    End Sub

End Module
